import { getStore } from "@netlify/blobs";
import { createHash, timingSafeEqual } from "node:crypto";

const KEY = "site";
const MAX_BYTES = 300_000;

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
    },
  });

const sha = (s) => createHash("sha256").update(String(s)).digest();
const sameSecret = (a, b) => timingSafeEqual(sha(a), sha(b));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export default async (req) => {
  const store = getStore("sinf5d");

  // Hamma o'qiy oladi
  if (req.method === "GET") {
    const data = await store.get(KEY, { type: "json" });
    return json({ data: data ?? null });
  }

  if (req.method === "POST" || req.method === "PUT") {
    const secret = process.env.ADMIN_PASSWORD;
    if (!secret) return json({ error: "no_password_set" }, 503);

    const given = req.headers.get("x-admin-password") || "";
    if (!sameSecret(given, secret)) {
      await sleep(600); // taxmin qilib topishni sekinlashtiradi
      return json({ error: "bad_password" }, 401);
    }

    // POST: faqat parolni tekshirish
    if (req.method === "POST") return json({ ok: true });

    // PUT: saqlash
    const text = await req.text();
    if (text.length > MAX_BYTES) return json({ error: "too_big" }, 413);
    let body;
    try {
      body = JSON.parse(text);
    } catch {
      return json({ error: "bad_json" }, 400);
    }
    if (!body || typeof body !== "object" || Array.isArray(body)) {
      return json({ error: "bad_shape" }, 400);
    }
    body.updated = new Date().toISOString();
    await store.setJSON(KEY, body);
    return json({ ok: true });
  }

  return json({ error: "method_not_allowed" }, 405);
};

export const config = { path: "/api/data" };
